package com.example.earthquakemonitor

class Feature(val id: String, val properties: Properties, val geometry:Geometry)
